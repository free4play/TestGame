﻿#pragma strict

public function StartGame () {
	Application.LoadLevel( 'Level' );
}