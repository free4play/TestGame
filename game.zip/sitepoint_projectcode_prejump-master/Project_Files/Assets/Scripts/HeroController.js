﻿#pragma strict

public function SetPosition ( x : float, z : float ) {
	transform.position.x = x;
	transform.position.z = z;
}